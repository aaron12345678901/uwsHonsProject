<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id']) && isset($data['exercise_name'])) {
    $workoutsid = $data['id'];
    $exercise_name = $data['exercise_name'];

    // Get the exercise ID based on name
    $stmt = $conn->prepare("SELECT id FROM exercises WHERE name = ?");
    $stmt->bind_param("s", $exercise_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $exercise_id = $row['id'];

        // Now delete from workout_exercises
        $stmt = $conn->prepare("DELETE FROM workout_exercises WHERE workout_id = ? AND exercise_id = ?");
        $stmt->bind_param("ii", $workoutsid, $exercise_id);

        if ($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["error" => "Failed to delete exercise"]);
        }
    } else {
        echo json_encode(["error" => "Exercise not found"]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Missing parameters"]);
}

$conn->close();
?>
