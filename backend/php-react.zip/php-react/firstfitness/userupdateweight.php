<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

$data = json_decode(file_get_contents("php://input"));

if (isset($data->id) && isset($data->weightstone) && isset($data->weightpounds)) {
    $id = $data->id;
    $weightStone = $data->weightstone;
    $weightPounds = $data->weightpounds;

    $sql = "UPDATE users SET weightstone=?, weightpounds=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $weightStone, $weightPounds, $id);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Weight updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update weight"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["message" => "Invalid input"]);
}
?>
