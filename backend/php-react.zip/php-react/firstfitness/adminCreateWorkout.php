<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

if(isset($data->user_id, $data->name, $data->level)) {
    $user_id = $data->user_id;
    $name = $conn->real_escape_string($data->name);
    $level = $conn->real_escape_string($data->level);

    // Insert new workout with is_prebuilt = 1
    $insertQuery = "INSERT INTO workouts (user_id, name, is_prebuilt,level) VALUES (?, ?, 1,?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("iss", $user_id, $name,$level);
    
    if($stmt->execute()) {
        echo json_encode(["success" => true, "workout_id" => $stmt->insert_id]);
    } else {
        echo json_encode(["success" => false, "error" => "Failed to insert workout"]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid input"]);
}

$conn->close();
?>
