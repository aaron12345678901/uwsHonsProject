<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->user_id, $data->name, $data->day_of_week)) {
    $user_id = $data->user_id;
    $name = $data->name;
    $day_of_week = $data->day_of_week;

    // Check if workout already exists
    $checkQuery = "SELECT id FROM workouts WHERE user_id = ? AND day_of_week = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("is", $user_id, $day_of_week);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0) {
        echo json_encode(["success" => false, "error" => "Workout already exists"]);
    } else {
        $stmt->close();
        
        // Insert new workout
        $insertQuery = "INSERT INTO workouts (user_id, name, day_of_week) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("iss", $user_id, $name, $day_of_week);
        
        if($stmt->execute()) {
            echo json_encode(["success" => true, "workout_id" => $stmt->insert_id]);
        } else {
            echo json_encode(["success" => false, "error" => "Failed to insert workout"]);
          
        }
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid input"]);
}

$conn->close();
?>