<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Database connection settings
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die(json_encode(["Status" => "500", "Message" => "Connection failed: " . mysqli_connect_error()]));
}

// Check if a file is uploaded
$targetDir = "../frontend/public/exercise-images/";
$imagePath = "";

if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
    $imageName = basename($_FILES['img']['name']);
    $targetFilePath = $targetDir . $imageName;

    if (move_uploaded_file($_FILES['img']['tmp_name'], $targetFilePath)) {
        $imagePath = "exercise-images/" . $imageName;
    } else {
        echo json_encode(["Status" => "500", "Message" => "Error uploading the image"]);
        exit;
    }
}

// Retrieve form data
$name = mysqli_real_escape_string($conn, $_POST['name']);
$muscle_group = mysqli_real_escape_string($conn, $_POST['muscle_group']);
$equipment_needed = (int)$_POST['equipment_needed'];
$time = isset($_POST['time']) ? (int)$_POST['time'] : NULL;
$exercise_reps = (int)$_POST['exercise_reps'];
$exercise_sets = (int)$_POST['exercise_sets'];
$rest_between_sets = (int)$_POST['rest_between_sets'];

// Insert the exercise into the database
$sql = "INSERT INTO exercises (name, img, muscle_group, equipment_needed, time, Exercise_Reps, Exercise_Sets, Rest_Between_Sets) 
        VALUES ('$name', '$imagePath', '$muscle_group', $equipment_needed, $time, $exercise_reps, $exercise_sets, $rest_between_sets)";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["Status" => "201", "Message" => "Exercise added successfully"]);
} else {
    echo json_encode(["Status" => "500", "Message" => "Error: " . mysqli_error($conn)]);
}

mysqli_close($conn);

?>

