<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

if (isset($_GET['id']) && isset($_GET['day'])) {
    $user_id = $_GET['id'];
    $day = $_GET['day'];

    // First, get the workout_id even if no exercises exist
    $stmt = $conn->prepare("SELECT id AS workout_id, name AS workout_name FROM workouts WHERE user_id = ? AND day_of_week = ?");
    $stmt->bind_param("is", $user_id, $day);
    $stmt->execute();
    $workout_result = $stmt->get_result();
    
    if ($workout = $workout_result->fetch_assoc()) {
        $workout_id = $workout['workout_id'];
        $workout_name = $workout['workout_name'];
    } else {
        echo json_encode(["error" => "No workout found for the given user and day"]);
        exit;
    }

    // Now fetch exercises associated with the workout
    $stmt = $conn->prepare(
        "SELECT 
            exercises.name AS exercise_name,
            exercises.img AS exercise_image,
            exercises.time,
            exercises.Exercise_Reps,
            exercises.Exercise_Sets,
            exercises.Rest_Between_Sets,
            users.workouts_complete
        FROM 
            firststepfitness.exercises
        JOIN 
            firststepfitness.workout_exercises 
            ON exercises.id = workout_exercises.exercise_id
        JOIN 
            firststepfitness.users 
            ON users.id = ?
        WHERE 
            workout_exercises.workout_id = ?"
    );

    $stmt->bind_param("ii", $user_id, $workout_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        "workout_id" => $workout_id,
        "workout_name" => $workout_name,
        "exercises" => $data
    ]);

    $stmt->close();
} else {
    echo json_encode(["error" => "User ID or day not provided"]);
}

$conn->close();
