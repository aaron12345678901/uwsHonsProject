<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . mysqli_connect_error()]);
    exit;
}

// Read the incoming JSON payload
$inputData = json_decode(file_get_contents("php://input"), true);

if (!$inputData) {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
    exit;
}

// Extract form data
$name = $inputData['name'];
$email = $inputData['email'];
$age = $inputData['age'];
$weightStone = $inputData['weightstone'];
$weightLbs = $inputData['weightlbs'];
$password = $inputData['password'];
$experience = $inputData['experience'];
$hashPassword = password_hash($password, PASSWORD_DEFAULT); // Secure password hashing

// Insert the data into the database
$sql = "INSERT INTO users (name, email, age, weightstone, weightpounds, password, experience) 
        VALUES ('$name', '$email', '$age', '$weightStone', '$weightLbs', '$hashPassword', '$experience')";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["success" => true, "message" => "User registered successfully. please Log in."]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . mysqli_error($conn)]);
}

mysqli_close($conn);
?>