<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

if (!isset($_GET['id'])) {
    echo json_encode(["success" => false, "error" => "Workout ID is required"]);
    exit();
}

$workout_id = intval($_GET['id']);

$sql = "SELECT 
    workouts.id AS workout_id, 
    workouts.name AS workout_name, 
    exercises.id AS exercise_id, 
    exercises.name AS exercise_name, 
    exercises.Exercise_Reps, 
    exercises.Exercise_Sets, 
    exercises.time, 
    exercises.Rest_Between_Sets, 
    exercises.img
FROM workouts
LEFT JOIN workout_exercises ON workouts.id = workout_exercises.workout_id
LEFT JOIN exercises ON workout_exercises.exercise_id = exercises.id
WHERE workouts.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $workout_id);
$stmt->execute();
$result = $stmt->get_result();

$workout_data = [
    "workout_id" => $workout_id,
    "workout_name" => "",
    "exercises" => []
];

while ($row = $result->fetch_assoc()) {
    if (!$workout_data['workout_name']) {
        $workout_data['workout_name'] = $row['workout_name'];
    }
    if ($row['exercise_name']) {
        $workout_data['exercises'][] = [
            "exercise_name" => $row['exercise_name'],
            "Exercise_Reps" => $row['Exercise_Reps'],
            "Exercise_Sets" => $row['Exercise_Sets'],
            "time" => $row['time'],
            "Rest_Between_Sets" => $row['Rest_Between_Sets'],
            "img" => $row['img']
        ];
    }
}

$stmt->close();
$conn->close();

echo json_encode($workout_data);
