<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Handle raw JSON data for non-file fields
$data = isset($_POST['jsonData']) ? json_decode($_POST['jsonData'], true) : null;

if (!$data) {
    echo json_encode(["error" => "Invalid JSON input or missing jsonData"]);
    exit;
}
// Check if all required fields are present
if (!$data || !isset($data['id'], $data['name'], $data['Exercise_Reps'], $data['Exercise_Sets'], $data['Rest_Between_Sets'], $data['time'], $data['muscle_group'], $data['equipment_needed'])) {
    echo json_encode(["error" => "Invalid input"]);
    exit;
}

$id = (int) $data['id'];
$name = $data['name'];
$Exercise_Reps = (int) $data['Exercise_Reps'];
$Exercise_Sets = (int) $data['Exercise_Sets'];
$Rest_Between_Sets = (int) $data['Rest_Between_Sets'];
$time = (int) $data['time'];
$muscle_group = $data['muscle_group'];
$equipment_needed = (int) $data['equipment_needed'];

// Handle file upload
$imagePath = "";
if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
    $targetDir = "../frontend/public/exercise-images/";
    $imageName = uniqid() . "_" . basename($_FILES['img']['name']); // Unique file name
    $targetFilePath = $targetDir . $imageName;

    if (move_uploaded_file($_FILES['img']['tmp_name'], $targetFilePath)) {
        $imagePath = "exercise-images/" . $imageName;
    } else {
        echo json_encode(["Status" => "500", "Message" => "Error uploading the image"]);
        exit;
    }
}

// Update database, including image if uploaded
if (!empty($imagePath)) {
    $stmt = $conn->prepare("UPDATE exercises SET name=?, Exercise_Reps=?, Exercise_Sets=?, Rest_Between_Sets=?, time=?, muscle_group=?, equipment_needed=?, img=? WHERE id=?");
    $stmt->bind_param("siiiisssi", $name, $Exercise_Reps, $Exercise_Sets, $Rest_Between_Sets, $time, $muscle_group, $equipment_needed, $imagePath, $id);
} else {
    $stmt = $conn->prepare("UPDATE exercises SET name=?, Exercise_Reps=?, Exercise_Sets=?, Rest_Between_Sets=?, time=?, muscle_group=?, equipment_needed=? WHERE id=?");
    $stmt->bind_param("siiiissi", $name, $Exercise_Reps, $Exercise_Sets, $Rest_Between_Sets, $time, $muscle_group, $equipment_needed, $id);
}

if ($stmt->execute()) {
    echo json_encode(["message" => "Exercise updated successfully"]);
} else {
    echo json_encode(["error" => "Failed to update: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>