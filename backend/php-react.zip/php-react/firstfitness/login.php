<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

// Database connection settings
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the email and password from the query parameters
$email = $_GET['email'];
$password = $_GET['password'];

// Check if the user exists with the provided email
$sql = "SELECT * FROM users WHERE email='$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $hashed_password = $row['password'];

    // Verify the hashed password
    if (password_verify($password, $hashed_password)) {
        $name = $row['name'];
        $id = $row['id'];
        $is_admin = $row['is_admin'];
 



        // Return success response
        $response = array(
            "Status" => "200",
            "name" => $name,
            "email" => $email,
       


            "id" => $id,
            "is_admin" => $is_admin
        );
    } else {
        $response = array(
            "Status" => "401",
            "Message" => "Invalid email or password."
        );
    }
} else {
    $response = array(
        "Status" => "401",
        "Message" => "Invalid email or password."
    );
}

// Return response as JSON
echo json_encode($response);

// Close the database connection
mysqli_close($conn);

?>