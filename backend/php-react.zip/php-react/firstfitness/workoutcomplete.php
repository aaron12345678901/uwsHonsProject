<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id'])) {
    $user_id = $data['id'];

    // Increment workouts_complete by 1
    $stmt = $conn->prepare("UPDATE users SET workouts_complete = workouts_complete + 1 WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Workout completed successfully!"]);
    } else {
        echo json_encode(["error" => "Failed to complete workout."]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "User ID not provided"]);
}

$conn->close();