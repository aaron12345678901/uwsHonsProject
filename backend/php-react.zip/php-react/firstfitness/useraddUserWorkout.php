<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

if (isset($data->userId) && isset($data->exerciseId)  && isset($data->workoutId)    ) {
    $userId = $conn->real_escape_string($data->userId);
    $exerciseId = $conn->real_escape_string($data->exerciseId);

    $workoutId = $conn->real_escape_string($data->workoutId);

    $sql = "INSERT INTO workout_exercises (workout_id, exercise_id) VALUES (' $workoutId', '$exerciseId')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => "Exercise added successfully"]);
    } else {
        echo json_encode(["error" => "Error adding exercise: " . $conn->error]);
    }
} else {
    echo json_encode(["error" => "Invalid input"]);
}

$conn->close();
?>