<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);


if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

if (isset($_GET['id'])) {
    $workout_id = $_GET['id'];
    
    // Fetch workout details
    $stmt = $conn->prepare("SELECT id AS workout_id, name AS workout_name, day_of_week FROM workouts WHERE id = ?");
    $stmt->bind_param("i", $workout_id);
    $stmt->execute();
    $workout_result = $stmt->get_result();
    
    if ($workout = $workout_result->fetch_assoc()) {
        $workout_name = $workout['workout_name'];
        $day_of_week = $workout['day_of_week'];
    } else {
        echo json_encode(["error" => "No workout found for the given ID"]);
        exit;
    }
    
    // Fetch exercises associated with the workout
    $stmt = $conn->prepare(
        "SELECT 
            exercises.name AS exercise_name,
            exercises.img AS exercise_image,
            exercises.time,
            exercises.Exercise_Reps,
            exercises.Exercise_Sets,
            exercises.Rest_Between_Sets
        FROM 
            exercises
        JOIN 
            workout_exercises ON exercises.id = workout_exercises.exercise_id
        WHERE 
            workout_exercises.workout_id = ?"
    );
    
    $stmt->bind_param("i", $workout_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $exercises = [];
    while ($row = $result->fetch_assoc()) {
        $exercises[] = $row;
    }

    echo json_encode([
        "workout_id" => $workout_id,
        "workout_name" => $workout_name,
        "day_of_week" => $day_of_week,
        "exercises" => $exercises
    ]);

    $stmt->close();
} else {
    echo json_encode(["error" => "Workout ID not provided"]);
}

$conn->close();
