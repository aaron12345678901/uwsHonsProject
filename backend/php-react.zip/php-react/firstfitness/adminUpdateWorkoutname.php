<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->workout_id) || !isset($data->new_workout_name)) {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
    exit();
}

$workout_id = $data->workout_id;
$new_workout_name = trim($data->new_workout_name);

// Prepare the SQL statement to prevent SQL injection
$stmt = $conn->prepare("UPDATE workouts SET name = ? WHERE id = ?");$stmt->bind_param("si", $new_workout_name, $workout_id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Workout name updated"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update"]);
}

$stmt->close();
$conn->close();
?>
