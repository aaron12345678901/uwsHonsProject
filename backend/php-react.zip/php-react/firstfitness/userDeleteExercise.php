<?php
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'firststepfitness';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id']) && isset($data['day']) && isset($data['exercise_name'])) {
    $user_id = $data['id'];
    $day = $data['day'];
    $exercise_name = $data['exercise_name'];

    // Prepare the delete statement
    $stmt = $conn->prepare("
        DELETE workout_exercises FROM workout_exercises 
        JOIN workouts ON workout_exercises.workout_id = workouts.id
        JOIN users ON workouts.user_id = users.id
        JOIN exercises ON workout_exercises.exercise_id = exercises.id
        WHERE users.id = ? AND workouts.day_of_week = ? AND exercises.name = ?
    ");
    
    $stmt->bind_param("iss", $user_id, $day, $exercise_name);
    
    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["error" => "Failed to delete exercise"]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Missing parameters"]);
}

$conn->close();